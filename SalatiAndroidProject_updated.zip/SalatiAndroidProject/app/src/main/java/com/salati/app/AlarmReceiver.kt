package com.salati.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val work = intent?.getBooleanExtra("work_alarm", false) ?: false
        if (work) {
            if (!AlarmScheduler.isWorkEnabled(context)) return
        } else if (!AlarmScheduler.isEnabled(context)) return

        val service = Intent(context, AlarmAudioService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(service)
        else context.startService(service)

        if (work) AlarmScheduler.restoreWork(context) else AlarmScheduler.restore(context)
    }
}
