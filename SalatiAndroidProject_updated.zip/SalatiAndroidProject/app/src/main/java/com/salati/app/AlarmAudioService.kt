package com.salati.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.IBinder

class AlarmAudioService : Service() {
    private var player: MediaPlayer? = null
    private val channelId = "salati_active_alarm"

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val stopIntent = Intent(this, StopAlarmReceiver::class.java)
        val stopPending = PendingIntent.getBroadcast(
            this, 991, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("صلاتي")
            .setContentText("حان موعد المنبه — اضغط إيقاف لإسكات الصوت")
            .setOngoing(true)
            .addAction(android.R.drawable.ic_media_pause, "إيقاف الصوت", stopPending)
            .build()
        startForeground(991, notification)
        val savedAdhan = getSharedPreferences("salati_media", MODE_PRIVATE)
            .getString("adhan_uri", null)
        val alarmAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
        try {
            player = MediaPlayer().apply {
                setAudioAttributes(alarmAttributes)
                if (!savedAdhan.isNullOrBlank()) {
                    try {
                        setDataSource(this@AlarmAudioService, android.net.Uri.parse(savedAdhan))
                    } catch (_: Exception) {
                        reset()
                        val fallback = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                        setDataSource(this@AlarmAudioService, fallback)
                    }
                } else {
                    val fallback = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                        ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                    setDataSource(this@AlarmAudioService, fallback)
                }
                isLooping = true
                prepare()
                start()
            }
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "منبه صلاتي النشط", NotificationManager.IMPORTANCE_HIGH)
            channel.description = "إشعار مستمر أثناء تشغيل صوت منبه الفجر فقط"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    override fun onDestroy() {
        try { player?.stop() } catch (_: Exception) { }
        player?.release()
        player = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
