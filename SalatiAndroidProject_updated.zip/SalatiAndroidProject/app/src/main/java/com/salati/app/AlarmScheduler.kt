package com.salati.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

object AlarmScheduler {
    private const val PREFS = "salati_alarm"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_TIME = "time"
    private const val WORK_ENABLED = "work_enabled"
    private const val WORK_TIME = "work_time"
    private const val REQUEST_CODE = 4107
    private const val WORK_REQUEST_CODE = 4108

    fun isEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, false)

    fun isWorkEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(WORK_ENABLED, false)

    fun schedule(context: Context, timestamp: Long) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_ENABLED, true).putLong(KEY_TIME, timestamp).apply()
        setExact(context, timestamp, false)
    }

    fun scheduleWork(context: Context, timestamp: Long) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(WORK_ENABLED, true).putLong(WORK_TIME, timestamp).apply()
        setExact(context, timestamp, true)
    }

    private fun setExact(context: Context, timestamp: Long, work: Boolean) {
        val manager = context.getSystemService(AlarmManager::class.java)
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = if (work) "com.salati.app.WORK_ALARM" else "com.salati.app.FAJR_ALARM"
            putExtra("work_alarm", work)
        }
        val requestCode = if (work) WORK_REQUEST_CODE else REQUEST_CODE
        val pending = PendingIntent.getBroadcast(
            context, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try {
            if (Build.VERSION.SDK_INT >= 23) manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timestamp, pending)
            else manager.setExact(AlarmManager.RTC_WAKEUP, timestamp, pending)
        } catch (_: SecurityException) { }
    }

    fun cancel(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_ENABLED, false).remove(KEY_TIME).apply()
        cancelPending(context, false)
    }

    fun cancelWork(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(WORK_ENABLED, false).remove(WORK_TIME).apply()
        cancelPending(context, true)
    }

    private fun cancelPending(context: Context, work: Boolean) {
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = if (work) "com.salati.app.WORK_ALARM" else "com.salati.app.FAJR_ALARM"
            putExtra("work_alarm", work)
        }
        val pending = PendingIntent.getBroadcast(
            context, if (work) WORK_REQUEST_CODE else REQUEST_CODE, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        context.getSystemService(AlarmManager::class.java).cancel(pending)
    }

    fun restore(context: Context) = restoreOne(context, false)
    fun restoreWork(context: Context) = restoreOne(context, true)

    private fun restoreOne(context: Context, work: Boolean) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val enabledKey = if (work) WORK_ENABLED else KEY_ENABLED
        val timeKey = if (work) WORK_TIME else KEY_TIME
        if (!prefs.getBoolean(enabledKey, false)) return
        var time = prefs.getLong(timeKey, 0L)
        if (time <= System.currentTimeMillis()) {
            val cal = Calendar.getInstance().apply {
                timeInMillis = if (time > 0) time else System.currentTimeMillis()
                add(Calendar.DAY_OF_YEAR, 1)
            }
            time = cal.timeInMillis
            prefs.edit().putLong(timeKey, time).apply()
        }
        setExact(context, time, work)
    }
}
