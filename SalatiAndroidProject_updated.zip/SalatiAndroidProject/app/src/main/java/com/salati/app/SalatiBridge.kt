package com.salati.app

import android.content.Context
import android.webkit.JavascriptInterface

class SalatiBridge(private val context: Context) {
    @JavascriptInterface
    fun scheduleAlarm(timestamp: Long) = AlarmScheduler.schedule(context, timestamp)

    @JavascriptInterface
    fun cancelAlarm() = AlarmScheduler.cancel(context)

    @JavascriptInterface
    fun isAlarmEnabled(): Boolean = AlarmScheduler.isEnabled(context)

    @JavascriptInterface
    fun scheduleWorkAlarm(timestamp: Long) = AlarmScheduler.scheduleWork(context, timestamp)

    @JavascriptInterface
    fun cancelWorkAlarm() = AlarmScheduler.cancelWork(context)

    @JavascriptInterface
    fun isWorkAlarmEnabled(): Boolean = AlarmScheduler.isWorkEnabled(context)

    @JavascriptInterface
    fun getSavedAdhanUri(): String =
        context.getSharedPreferences("salati_media", Context.MODE_PRIVATE)
            .getString("adhan_uri", "") ?: ""

    @JavascriptInterface
    fun clearSavedAdhanUri() {
        context.getSharedPreferences("salati_media", Context.MODE_PRIVATE)
            .edit().remove("adhan_uri").apply()
    }

    @JavascriptInterface
    fun stopAlarmSound() {
        context.stopService(android.content.Intent(context, AlarmAudioService::class.java))
    }
}
