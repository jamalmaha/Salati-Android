package com.salati.app

import android.content.Context
import android.webkit.JavascriptInterface

class SalatiBridge(private val context: Context) {
    @JavascriptInterface
    fun scheduleAlarm(timestamp: Long) {
        AlarmScheduler.schedule(context, timestamp)
    }

    @JavascriptInterface
    fun cancelAlarm() {
        AlarmScheduler.cancel(context)
    }

    @JavascriptInterface
    fun isAlarmEnabled(): Boolean {
        return AlarmScheduler.isEnabled(context)
    }

    @JavascriptInterface
    fun stopAlarmSound() {
        context.stopService(android.content.Intent(context, AlarmAudioService::class.java))
    }
}
