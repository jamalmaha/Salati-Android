package com.salati.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper

class AlarmAudioService : Service() {
    private var player: MediaPlayer? = null
    private var toneGenerator: ToneGenerator? = null
    private val handler = Handler(Looper.getMainLooper())
    private val channelId = "salati_active_alarm"
    private var toneStep = 0
    private var tonePattern: List<Pair<Int, Long>> = emptyList()

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val stopIntent = Intent(this, StopAlarmReceiver::class.java)
        val stopPending = PendingIntent.getBroadcast(
            this, 991, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val fullScreenIntent = Intent(this, AlarmStopActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        val fullScreenPending = PendingIntent.getActivity(
            this, 992, fullScreenIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("صلاتي")
            .setContentText("المنبه يعمل — اسحب زر الإيقاف للأعلى")
            .setCategory(Notification.CATEGORY_ALARM)
            .setPriority(Notification.PRIORITY_MAX)
            .setVisibility(Notification.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setFullScreenIntent(fullScreenPending, true)
            .setContentIntent(fullScreenPending)
            .addAction(android.R.drawable.ic_media_pause, "إيقاف الصوت", stopPending)
            .build()
        startForeground(991, notification)

        val preferences = getSharedPreferences("salati_media", MODE_PRIVATE)
        val savedAdhan = preferences.getString("adhan_uri", null)
        if (!savedAdhan.isNullOrBlank() && playSavedAdhan(savedAdhan)) return
        startSelectedTone(preferences.getString("alarm_tone", "calm") ?: "calm")
    }

    private fun playSavedAdhan(uriString: String): Boolean {
        return try {
            val alarmAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            player = MediaPlayer().apply {
                setAudioAttributes(alarmAttributes)
                setDataSource(this@AlarmAudioService, android.net.Uri.parse(uriString))
                isLooping = true
                prepare()
                start()
            }
            true
        } catch (_: Exception) {
            try { player?.release() } catch (_: Exception) { }
            player = null
            false
        }
    }

    private fun startSelectedTone(selected: String) {
        toneGenerator = try { ToneGenerator(AudioManager.STREAM_ALARM, 90) } catch (_: Exception) { null }
        if (toneGenerator == null) {
            val fallback = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            try {
                player = MediaPlayer().apply {
                    setDataSource(this@AlarmAudioService, fallback)
                    isLooping = true
                    prepare()
                    start()
                }
            } catch (_: Exception) { stopSelf() }
            return
        }
        val beep = ToneGenerator.TONE_PROP_BEEP
        val ack = ToneGenerator.TONE_PROP_ACK
        val prompt = ToneGenerator.TONE_PROP_PROMPT
        val ring = ToneGenerator.TONE_SUP_RINGTONE
        val guard = ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD
        tonePattern = when (selected) {
            "islamic" -> listOf(ack to 420L, 0 to 180L, prompt to 500L, 0 to 180L, ack to 650L, 0 to 500L)
            "strong" -> listOf(ring to 900L, 0 to 250L, ring to 900L, 0 to 250L)
            "repeat" -> listOf(beep to 250L, 0 to 150L, beep to 250L, 0 to 150L, beep to 250L, 0 to 550L)
            "bell" -> listOf(prompt to 500L, 0 to 120L, prompt to 500L, 0 to 650L)
            "dawn" -> listOf(ack to 300L, 0 to 220L, prompt to 450L, 0 to 220L, ack to 650L, 0 to 650L)
            "chime" -> listOf(prompt to 700L, 0 to 250L, ack to 500L, 0 to 700L)
            "rising" -> listOf(beep to 180L, 0 to 100L, ack to 280L, 0 to 100L, prompt to 450L, 0 to 500L)
            "digital" -> listOf(guard to 160L, 0 to 100L, beep to 160L, 0 to 100L, guard to 160L, 0 to 600L)
            "birds" -> listOf(prompt to 220L, 0 to 120L, ack to 280L, 0 to 140L, prompt to 220L, 0 to 650L)
            "pulse" -> listOf(ring to 220L, 0 to 100L, ring to 220L, 0 to 100L, ring to 220L, 0 to 450L)
            "soft3" -> listOf(prompt to 350L, 0 to 180L, prompt to 350L, 0 to 180L, prompt to 350L, 0 to 750L)
            else -> listOf(prompt to 500L, 0 to 250L, ack to 500L, 0 to 650L)
        }
        toneStep = 0
        playNextToneStep()
    }

    private fun playNextToneStep() {
        if (toneGenerator == null || tonePattern.isEmpty()) return
        val step = tonePattern[toneStep % tonePattern.size]
        if (step.first != 0) toneGenerator?.startTone(step.first, step.second.toInt())
        toneStep++
        handler.postDelayed({ playNextToneStep() }, step.second)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "منبه صلاتي النشط", NotificationManager.IMPORTANCE_HIGH)
            channel.description = "إشعار مستمر أثناء تشغيل صوت منبه الفجر فقط"
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_NOT_STICKY

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { toneGenerator?.stopTone() } catch (_: Exception) { }
        toneGenerator?.release()
        toneGenerator = null
        try { player?.stop() } catch (_: Exception) { }
        player?.release()
        player = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
