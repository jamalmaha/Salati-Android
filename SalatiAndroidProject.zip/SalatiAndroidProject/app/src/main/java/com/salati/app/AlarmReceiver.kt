package com.salati.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (!AlarmScheduler.isEnabled(context)) return
        val service = Intent(context, AlarmAudioService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(service)
        else context.startService(service)
        // Keep a daily fallback. When the app is opened, fresh prayer times replace it.
        AlarmScheduler.restore(context)
    }
}
