package com.salati.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import java.util.Calendar

object AlarmScheduler {
    private const val PREFS = "salati_alarm"
    private const val KEY_ENABLED = "enabled"
    private const val KEY_TIME = "time"
    private const val REQUEST_CODE = 4107

    fun isEnabled(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, false)

    fun schedule(context: Context, timestamp: Long) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(KEY_ENABLED, true).putLong(KEY_TIME, timestamp).apply()
        setExact(context, timestamp)
    }

    private fun setExact(context: Context, timestamp: Long) {
        val manager = context.getSystemService(AlarmManager::class.java)
        val intent = Intent(context, AlarmReceiver::class.java)
        val pending = PendingIntent.getBroadcast(
            context, REQUEST_CODE, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try {
            if (Build.VERSION.SDK_INT >= 23) manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timestamp, pending)
            else manager.setExact(AlarmManager.RTC_WAKEUP, timestamp, pending)
        } catch (_: SecurityException) { }
    }

    fun cancel(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(KEY_ENABLED, false).remove(KEY_TIME).apply()
        val intent = Intent(context, AlarmReceiver::class.java)
        val pending = PendingIntent.getBroadcast(
            context, REQUEST_CODE, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        context.getSystemService(AlarmManager::class.java).cancel(pending)
    }

    fun restore(context: Context) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!prefs.getBoolean(KEY_ENABLED, false)) return
        var time = prefs.getLong(KEY_TIME, 0L)
        if (time <= System.currentTimeMillis()) {
            val cal = Calendar.getInstance().apply {
                timeInMillis = if (time > 0) time else System.currentTimeMillis()
                add(Calendar.DAY_OF_YEAR, 1)
            }
            time = cal.timeInMillis
            prefs.edit().putLong(KEY_TIME, time).apply()
        }
        setExact(context, time)
    }
}
