package com.salati.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class AlarmStopActivity : Activity() {
    private var downY = 0f
    private var swipeView: LinearLayout? = null
    private var swipeStartTranslation = 0f
    private val gold = Color.rgb(229, 193, 107)
    private val dark = Color.rgb(5, 25, 19)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
        )
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        window.statusBarColor = dark
        window.navigationBarColor = dark
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_STABLE

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(28), dp(24), dp(24))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.rgb(5, 25, 19), Color.rgb(16, 55, 42)))
        }
        val brand = text("صلاتي", 25, gold, true).apply { gravity = Gravity.CENTER }
        root.addView(brand, LinearLayout.LayoutParams(-1, dp(55)))

        val bell = text("🔔", 74, gold, true).apply { gravity = Gravity.CENTER }
        root.addView(bell, LinearLayout.LayoutParams(-1, dp(130)))

        val title = text("حان وقت المنبه", 30, Color.WHITE, true).apply { gravity = Gravity.CENTER }
        root.addView(title, LinearLayout.LayoutParams(-1, dp(62)))
        val subtitle = text("منبه صلاتي يعمل الآن", 18, Color.rgb(220, 226, 220), false).apply { gravity = Gravity.CENTER }
        root.addView(subtitle, LinearLayout.LayoutParams(-1, dp(45)))

        val spacer = View(this)
        root.addView(spacer, LinearLayout.LayoutParams(1, 0, 1f))

        val hint = text("اسحب زر الإيقاف إلى الأعلى", 20, gold, true).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(18))
        }
        root.addView(hint, LinearLayout.LayoutParams(-1, dp(60)))

        val slider = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(20), dp(16), dp(20))
            background = rounded(gold, dp(26))
            elevation = dp(8).toFloat()
        }
        val handle = text("↑", 38, dark, true).apply { gravity = Gravity.CENTER }
        slider.addView(handle, LinearLayout.LayoutParams(-1, dp(52)))
        val sliderText = text("اسحب للأعلى لإيقاف الصوت", 21, dark, true).apply { gravity = Gravity.CENTER }
        slider.addView(sliderText, LinearLayout.LayoutParams(-1, dp(48)))
        swipeView = slider
        root.addView(slider, LinearLayout.LayoutParams(-1, dp(142)))

        val tapStop = text("أو اضغط هنا للإيقاف", 16, Color.WHITE, false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, dp(8))
            setOnClickListener { stopAlarm() }
        }
        root.addView(tapStop, LinearLayout.LayoutParams(-1, dp(50)))
        setContentView(root)

        root.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downY = event.rawY
                    swipeStartTranslation = slider.translationY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val delta = event.rawY - downY
                    if (delta < 0) slider.translationY = (swipeStartTranslation + delta).coerceAtLeast(-dp(260).toFloat())
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    val delta = event.rawY - downY
                    if (delta < -dp(120)) stopAlarm() else slider.animate().translationY(0f).setDuration(180).start()
                    true
                }
                else -> false
            }
        }
    }

    private fun stopAlarm() {
        stopService(Intent(this, AlarmAudioService::class.java))
        finishAndRemoveTask()
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean): TextView = TextView(this).apply {
        text = value
        textSize = size.toFloat()
        setTextColor(color)
        typeface = if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        gravity = Gravity.CENTER
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onBackPressed() {
        // Keep the alarm screen visible; use the upward swipe or stop control.
    }
}
